import Vue from 'vue'
import App from './App'
// import Request from 'js_sdk/pocky-request/pocky-request v.2.0.4/core/index.js'
Vue.config.productionTip = false;
//Vue.prototype.$axios = axios
//Vue.prototype.axios = Request();
App.mpType = 'app'
//file:///D:/HBuilder/test/js_sdk
const app = new Vue({
    ...App
	
})
app.$mount()
