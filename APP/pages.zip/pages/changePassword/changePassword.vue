<template>
	<view class="content">
			<view class="uni-form-item2 uni-column">
				<input type="password" v-model="changeForm.password" class="uni-input" @input="inputData2" name="input" placeholder="新密码" />
			</view>
			<view class="uni-form-item4 uni-column">
				<input v-model="changeForm.email" class="uni-input" @input="inputData4" name="input" placeholder="输入邮箱" />
			</view >
			<view class="uni-form-item6 uni-column">
				<button size="mini" @click="sendKey">获取验证码</button>
			</view>
			<view class="uni-form-item5 uni-column">
				<input v-model="changeForm.key" class="uni-input" @input="inputData5" name="input" placeholder="输入验证码" />
			</view>
			<view class="uni-padding-wrap uni-common-mt">
				<button @click="goLogin">确认</button>
			</view>
			<view class="uni-padding-wrap2 uni-common-mt">
				<button @click="goHeadpage_user">取消</button>
			</view>
			<view>
				<!-- 提示信息弹窗 -->
				<uni-popup ref="message" type="message"><uni-popup-message :type="msgType" :message="messageText" :duration="2000"></uni-popup-message></uni-popup>
			</view>
		</form>	
	</view>
</template>


<script>
	export default {
		data() {
			return {
				type: '',
				msgType: '',
				messageText: '这是一条成功提示',
				changeForm:{
					password:'',
					email:'',
					key:''
				},
			}
		},
		// onNavigationBarButtonTap:function(e){
		// 	this.text = e.text;
		// 	if(this.text=="返回"){
		// 		uni.navigateTo({
		// 			url:"/pages/index/index"
		// 		})
		// 	}
		// },
		onReady() {},
		methods: {
			change(e){
				console.log('当前模式：'+e.type+',状态：'+e.show);
			},
			toggle(type) {
				this.type = type
				// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
				this.$refs.popup.open(type)
			},
			inputData1:function(evt){
				this.oldPassword = evt.detail.value
			},
			inputData2:function(evt){
				this.newPassword = evt.detail.value
			},
			inputData3:function(evt){
				this.newPassword2 = evt.detail.value
			},
			inputData4:function(evt){
				this.email = evt.detail.value
			},
			inputData5:function(evt){
				this.code = evt.detail.value
			},
			sendKey(e){
				if(this.changeForm.email){
					uni.request({
						url:'http://192.168.43.217:5000/change_password_verify',
						method:"POST",
						data:this.changeForm,
						success:(res)=>{
							/*不传*/
						}
					})	
				}
			},
			goLogin:function(type){
				if(this.oldPassword!=""&&this.newpassword!=""&&this.newPassword2!=""&&this.email!=""&&this.code!="")
				{
					uni.request({
						url:'http://192.168.43.217:5000/change_password',
						method:"POST",
						data:this.changeForm,
						success:(res)=>{
							if(res.data.status==200){
								uni.switchTab({
									url:'/pages/login/login'
								})
							}
							else{
								/*登陆失败！！！！！！*/
							}
						}
					})
					// this.msgType = type,
					// this.messageText = '注册成功',
					// this.$refs.message.open(),
				}
				if(this.oldPassword==""||this.newpassword==""||this.newPassword2==""||this.email==""||this.code=="")
				{
					this.msgType = type,
					this.messageText = '失败，请检查输入',
					this.$refs.message.open()
				}
			},
			goWhichHeadpage:function(evt){
				this.radioType=evt.detail.value
			},
			
			goHeadpage_user(e){
					uni.switchTab({
						url:'/pages/index/index'
					})
			}	
		}
	}
</script>

<style>
	.uni-form-item3{
		margin-top: 50rpx;
	}
	.uni-form-item{
		margin-top: 100rpx;
	}
	.uni-form-item2{
		margin-top: -150rpx;
	}
	.uni-form-item4{
		margin-top: 50rpx;
	}
	.uni-form-item5{
		margin-top: 50rpx;
	}
	.uni-form-item6{
		margin-top: 25rpx;
	}
	.uni-padding-wrap{
		background-color: #ffffff;
		margin-top: 35rpx;
	}
	.uni-padding-wrap2{
		background-color: #ffffff;
		margin-top: 35rpx;
	}
	.uni-form-item .title {
	        padding: 20rpx 0;
	}
	.content {
		height: 1400rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #CAD6CA;
	}
	
	
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.title {
		font-size: 36rpx;
		color: #333333;
	}
	
	
	
	
	
	
	
	
	
	
	@import '@/common/uni-nvue.scss';
	@mixin flex {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
	}
	@mixin height {
		/* #ifndef APP-NVUE */
		height: 100%;
		/* #endif */
		/* #ifdef APP-NVUE */
		flex: 1;
		/* #endif */
	}
	.box {
		@include flex;
	}
	.button {
		@include flex;
		align-items: center;
		justify-content: center;
		flex: 1;
		height: 35px;
		margin: 0 5px;
		border-radius: 5px;
	}
	
	.button-text {
		color: #fff;
		font-size: 18px;
	}
	.popup-content {
		@include flex;
		align-items: center;
		justify-content: center;
		padding: 15px;
		height: 50px;
		background-color: #fff;
	}
	/* .popup-height {
		@include height;
		width: 200px;
	} */
	.text {
		font-size: 12px;
		color: #333;
	}
	.popup-success {
		color: #fff;
		background-color: #e1f3d8;
	}
	.popup-success2{
		color:#fff;
		background-color: #ffffff;
	}
	
	
	.popup-info {
		color: #fff;
		background-color: #f2f6fc;
	}
	.success-text {
		color: #000000;
	}
	
	.share {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
	}
	
</style>

