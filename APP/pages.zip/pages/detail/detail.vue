<template>
	<view>详情页</view>
</template>

<script>
</script>

<style>
</style>
