<template>
	<view class="content">
		<view>
			<uni-swiper-dot class="uni-swiper-dot-box" @clickItem=clickItem :info="info" :current="current">
				<swiper class="swiper-box" @change="change" :current="swiperDotIndex">
					<swiper-item v-for="(item, index) in info" :key="index">
						<view :class="swiper-item">
							<image :src='item.src' ></image>
						</view>
					</swiper-item>
				</swiper>
			</uni-swiper-dot>
		</view>
			<view class="example-body">
				<uni-card :isShadow="true" title="监控录像" mode="title" thumbnail="../../static/logo.png"
				 extra="点击查看监控" @click="clickCard">
					<view>
						<view class="image-box">
							<image class="image" mode="aspectFill" src="../../static/led/monitor.png" />	
						</view>
					</view>
				</uni-card>
			</view>
			
			<view class="example-body">
				<uni-card :isShadow="true" title="入侵信息" mode="title" thumbnail="../../static/logo.png"
				 extra="查看入侵信息"  @click="clickCard1">
					<view>
						<view class="image-box">
							<image class="image" mode="aspectFill" src="../../static/led/invade.png" />
						</view>
					</view>
					
				</uni-card>
			</view>
		<view>
			
			<view class="example-body">
				<uni-card :isShadow="true" title="用户管理" mode="title" thumbnail="../../static/logo.png"
				 extra="点击查看信息" @click="clickCard2">
					<view>
						<view class="image-box">
							<image class="image" mode="aspectFill" src="../../static/led/manage_admin.png" />
						</view>
					</view>
			
				</uni-card>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		components: {},
		data() {
			return {
				info: [
					{
						src:require('../../static/led/1.png')
					},
					{
						src:require('../../static/led/2.png')
					},
					{
						src:require('../../static/led/3.png')
					},
				],
				modeIndex: -1,
				styleIndex: -1,
				current:0,
				mode: 'default',
				swiperDotIndex: 0,
				text:''
			}
		},
		onNavigationBarButtonTap:function(e){
			this.text = e.text;
			if(this.text=="我的"){
				uni.switchTab({
					url:"/pages/index/index"
				})
			}
			if(this.text=="帮助"){
				uni.switchTab({
					url:"/pages/help/help"
				})
			}
		 },
		onLoad() {},
		methods: {
			change(e) {
				this.current = e.detail.current
			},
			clickItem(e) {
				this.swiperDotIndex = e
			},
			onBanner(index) {
				console.log(22222, index);
			},
			clickCard() {
				uni.navigateTo({
					url:'/pages/monitor/monitor_user'
				})
			},
			clickCard1(){
				uni.navigateTo({
					url:'/pages/invalid/invalid'
					
				})
			},
			clickCard2(){
				uni.navigateTo({
					url:"/pages/manage_admin/manage_admin"
				})
			}
		}
	}
</script>

<style lang="scss">
	@import '@/common/uni-nvue.scss';
	.content{
		background-color: #cad6ca;
	}
	.swiper-box {
		width: 100%;
		height:400rpx;
		.swiper-item{
			.image {
				width: 100%;
				height:100rpx
			}
		}
		
	}
	.example-body {
		/* #ifndef APP-NVUE */
		display: block;
		/* #endif */
		padding: 1px 0;
		background-color: #cad6ca;
	}
	.example-body-item {
	
		flex-direction: row;
		justify-content: center;
		align-items: center;
		margin: 15rpx;
		padding: 15rpx;
		height: 60rpx;
		/* #ifndef APP-NVUE */
		display: flex;
		padding: 0 15rpx;
		/* #endif */
		flex: 1;
		border-color: #e5e5e5;
		border-style: solid;
		border-width: 1px;
		border-radius: 5px;
	}
	
	
	
	.example-box {
		margin: 5px 0;
	}
	
	.image-box {
		/* #ifndef APP-NVUE */
		display: flex;
		flex-direction: column;
		/* #endif */
		height: 235rpx;
		overflow: hidden;
	}
	
	.image {
		/* #ifndef APP-NVUE */
		width: 100%;
		height: 100%;
		/* #endif */
		flex: 1;
	}
	
	.content-box {
		padding-top: 20rpx;
	}
	
	.content-box-text {
		font-size: 12px;
		line-height: 22px;
	}
</style>