<template>
	<view class="content">
		<view>
			<uni-swiper-dot class="uni-swiper-dot-box" @clickItem=clickItem :info="info" :current="current">
				<swiper class="swiper-box" @change="change" :current="swiperDotIndex">
					<swiper-item v-for="(item, index) in info" :key="index">
						<view :class="swiper-item">
							<image :src='item.src' ></image>
						</view>
					</swiper-item>
				</swiper>
			</uni-swiper-dot>
		</view>
		<view>
			<view class="example-body">
				<uni-card :isShadow="true" title="监控录像" mode="title" thumbnail="../../static/logo.png"
				 extra="点击查看监控" @click="clickCard">
					<view>
						<view class="image-box">
							<image class="image" mode="aspectFill" src="../../static/led/monitor.png" />
						</view>
					</view>
	
				</uni-card>
			</view>
		</view>
		<view>
			<view class="example-body">
				<uni-card :isShadow="true" title="入侵信息" mode="title" thumbnail="../../static/logo.png"
				 extra="查看入侵信息"  @click="clickCard1">
					<view>
						<view class="image-box">
							<image class="image" mode="aspectFill" src="../../static/led/invade.png" />
						</view>
					</view>
					
				</uni-card>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		components: {},
		data() {
			return {
				info: [
					{
						src:require('../../static/led/1.png')
					},
					{
						src:require('../../static/led/2.png')
					},
					{
						src:require('../../static/led/3.png')
					},
				],
				modeIndex: -1,
				styleIndex: -1,
				current:0,
				mode: 'default',
				swiperDotIndex: 0,
			}
		},
		onLoad() {},
		onNavigationBarButtonTap:function(e){
			this.text = e.text;
			if(this.text=="我的"){
				uni.switchTab({
					url:"/pages/index/index"
				})
			}
			if(this.text=="帮助"){
				uni.switchTab({
					url:"/pages/help/help"
				})
			}
		 },
		methods: {
			clickCard() {
				uni.navigateTo({
					url:'/pages/monitor/monitor_user'
				})
			},
			clickCard1(){
				uni.navigateTo({
					url:'/pages/invalid/invalid'
				})
			},
			change(e) {
				this.current = e.detail.current
			},
			clickItem(e) {
				this.swiperDotIndex = e
			},
			onBanner(index) {
				console.log(22222, index);
			}
		}
	}
</script>

<style lang="scss">
	@import '@/common/uni-nvue.scss';
	.swiper-box {
		width: 100%;
		height:400rpx;
		.swiper-item{
			.image {
				width: 100%;
				height:100rpx
			}
		}
		
	}
	.content{
		background-color: #cad6ca;
	}
	.image {
		width: 750rpx;
	}
	
	/* #ifndef APP-NVUE */
	::v-deep .image img {
		-webkit-user-drag: none;
		-khtml-user-drag: none;
		-moz-user-drag: none;
		-o-user-drag: none;
		user-drag: none;
	}
	/* #endif */
	
	@media screen and (min-width: 500px) {
				.uni-swiper-dot-box {
					width: 400px;
					margin: 0 auto;
					margin-top: 8px;
				}
	
				.image {
					width: 100%;
				}
	}
	
	
	
	.example-body {
		/* #ifndef APP-NVUE */
		display: block;
		/* #endif */
		padding: 1px 0;
		background-color: #cad6ca;
	}
	
	.example-box {
		margin: 5px 0;
	}
	
	.image-box {
		/* #ifndef APP-NVUE */
		display: flex;
		flex-direction: column;
		/* #endif */
		height: 235rpx;
		overflow: hidden;
	}
	
	.image {
		/* #ifndef APP-NVUE */
		width: 100%;
		height: 100%;
		/* #endif */
		flex: 1;
	}
	
	.content-box {
		padding-top: 20rpx;
	}
	
	.content-box-text {
		font-size: 12px;
		line-height: 22px;
	}
	
	.footer-box {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		justify-content: space-between;
		flex-direction: row;
	
	}
	
	.footer-box__item {
		align-items: center;
		padding: 2px 0;
		font-size: 12px;
		color: #666;
	}
</style>
