<template>
	<view class="body">
		<view class="h1">RVSS2021(Android)3.1Build0729</view>
		
		<view class="context">
			<view>此版本适用于Android 1.6及1.6以上操作系统系列手机，对于在其他操作系统平台的手机上使用本软件，出现的任何问题，RVSS不承担责任。 本"软件"是由第七组开发，非经RVSS或RVSS授权开发并正式发布的其它任何由本"软件"衍生的软件均属非法，RVSS保留追究法律责任的权利。下载、安装、使用此类软件，将可能导致不可预知的风险，由此产生的一切法律责任与纠纷一概与RVSS无关。本软件的下载，安装和使用完全免费，第七组不收取任何费用，下载使用过程中产生的GPRS数据流量费用，由运营商收取。</view>
			<view>用户不得利用本软件发表、传送、传播、储存违反国家法律、危害国家安全、祖国统一、社会稳定的内容，或任何不当的、侮辱诽谤的、淫秽的、暴力的及任何违反国家法律法规政策的内容；不得制造虚假身份以误导、欺骗或利用本软件批量发表、传送、传播广告信息。否则，RVSS有权终止用户账号使用。</view>
		</view>
		
		<view class="address" style="border-bottom:1px solid #e8e8e8;">
			<view>本软件的安装使用受《中华人民共和国刑法》的约束。</view>
			<view>组长热线：18518967013</view>
		</view>
		
		<view class="copyright">
			<view class="copyright-zh">RVSS 版权所有</view>
			<view class="copyright-en">Copyright © 2021 RVSS. All Rights Reserved.</view>
		</view>
	</view>
	
	
</template>

<script>
	export default {
		onNavigationBarButtonTap:function(e){
			this.text = e.text;
			if(this.text=="返回"){
				uni.navigateTo({
					url:"/pages/headpage/headpage_admin"
				})
			}
		},
	}
</script>

<style type="text/css">
	/* *{ margin:0; padding:0;} */
	.body{ 
		background-color:#CAD6CA;
		height: 1250rpx;
	}
	.h1{ height:30px; line-height:30px; border-bottom:1px solid #e8e8e8; padding:0 13px;font-size:12px;}
	/* h1 sub{ font-size:13px;} */
	.context{ padding:13px; font-size:12px; line-height:1.5;margin:0 0 15px 0;}
		/* .context p{ } */
	.copyright{ padding:13px;  font-size:12px; line-height:1.5; border-bottom:1px solid #e8e8e8; }
		.copyright-zh{ font-size:14px; font-weight:bold;}
		.copyright-en{ font-size:10px;}
	.address{ padding:13px; font-size:12px; line-height:1.5;}
</style>
