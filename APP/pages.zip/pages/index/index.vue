<template>
	<view class="content">
		
		<form @submit="formSubmit" @reset="formReset">
			<view class="uni-form-item uni-column">
				<view class="title"></view>
				<input v-model="showInfor.username" class="uni-input" @input="inputData1" name="input" placeholder="用户名">
			</view>
			<view class="uni-form-item2 uni-column">
				<input v-model="showInfor.email"    class="uni-input" @input="inputData2" name="input" placeholder="邮箱" />
			</view>
			
			<view class="uni-padding-wrap uni-common-mt">
				<button @click="changePassword">修改密码</button>
			</view>
			<view class="uni-padding-wrap2 uni-common-mt">
				<button @click="goLogin">退出</button>
			</view>
		</form>	
	</view>
</template>


<script>
	export default {
		data() {
			return {
				message:{
					msg:'get_information'
				},
				type: 'center',
				msgType: 'success',
				messageText: '这是一条成功提示',
				showInfor:{
					username:'name',
					email:'email'
				},
				title: '欢迎你'
				
			}
		},
		created(){
			console.log(this.showInfor);
			uni.request({
				url:'http://192.168.43.217:5000/message',
				method:"POST",
				data:this.message,
				success:(res)=>{
					console.log(this.showInfor),
					this.showInfor.email=res.data.email;
					this.showInfor.username=res.data.username;
				},
				
			});
			console.log("this"+this.showInfor);
		},
		onNavigationBarButtonTap:function(e){
			this.text = e.text;
			if(this.text=="返回"){
				uni.navigateTo({
					url:"/pages/headpage/headpage_admin"
				})
			}
		},
		onReady() {},
		methods: {
			changePassword(evt){
				uni.redirectTo({
					url:"/pages/changePassword/changePassword"
				})
			},
			messageToggle(type) {
				this.msgType = type
				this.messageText = `这是一条${type}消息提示`
				this.$refs.message.open()
			},
			goLogin:function(evt){
				uni.navigateTo({
					url:"/pages/login/login"
				})
			},
			inputData1:function(evt){
				this.userName = evt.detail.value,
				console.log(this.userName)
			},
			inputData2:function(evt){
				this.email = evt.detail.value,
				console.log(this.email)
			}
		}
	}
</script>

<style>
	.uni-form-item{
		margin-top: -250rpx;
	}
	.uni-form-item2{
		margin-top: 50rpx;
	}
	.uni-padding-wrap{
		margin-top: 100rpx;
	}
	.uni-padding-wrap2{
		background-color: #ffffff;
		margin-top: 50rpx;
	}
	.uni-form-item .title {
	        padding: 20rpx 0;
	}
	.content {
		height: 1250rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #cad6ca;
	}
	
	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 100rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.title {
		font-size: 36rpx;
		color: #333333;
	}
	
	
	
	
	
	
	
	
	
	
	@import '@/common/uni-nvue.scss';
	@mixin flex {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
	}
	@mixin height {
		/* #ifndef APP-NVUE */
		height: 100%;
		/* #endif */
		/* #ifdef APP-NVUE */
		flex: 1;
		/* #endif */
	}
	.box {
		@include flex;
	}
	.button {
		@include flex;
		align-items: center;
		justify-content: center;
		flex: 1;
		height: 35px;
		margin: 0 5px;
		border-radius: 5px;
	}
	
	.button-text {
		color: #fff;
		font-size: 18px;
	}
	.popup-content {
		@include flex;
		align-items: center;
		justify-content: center;
		padding: 15px;
		height: 50px;
		background-color: #fff;
	}
	/* .popup-height {
		@include height;
		width: 200px;
	} */
	.text {
		font-size: 12px;
		color: #333;
	}
	.popup-success {
		color: #fff;
		background-color: #e1f3d8;
	}
	.popup-success2{
		color:#fff;
		background-color: #ffffff;
	}
	
	
	.popup-info {
		color: #fff;
		background-color: #f2f6fc;
	}
	.success-text {
		color: #000000;
	}
	
	.share {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
	}
	
</style>
