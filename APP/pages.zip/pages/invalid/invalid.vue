<template>
	<view class="uni-container">
		<uni-table ref="table" :loading="loading" border  emptyText="暂无更多数据" >
			<uni-tr>
				<uni-th width="80" align="center">时间</uni-th>
				<uni-th width="80" align="center">地点</uni-th>
				<uni-th width="150"align="center">备注</uni-th>
				<!-- <uni-th width="204" align="center">管理</uni-th> -->
			</uni-tr>
			<uni-tr v-for="(item, index) in messageList" :key="index">
				<uni-td>{{ item[0] }}</uni-td>
				<uni-td>
					<view class="name">{{ item[1] }}</view>
				</uni-td>
				<uni-td align="center">{{ item[2] }}</uni-td>
			</uni-tr>
		</uni-table>
	</view>
</template>

<script>
	export default {
		created(){
			this.getMessageList();
			console.log(this.messageList)
		},
		data() {
			return {
				remarkForm:{
					time:'',
					place:'',
					mess:''
				},
				queryInfo:{
					qurey:'',
					pagenum:1,
					pagesize:10
				},
				total: 0,
				loading:false,
				messageList:[]
			}
		},
		methods: {
			getMessageList(){
				uni.request({
					url:'http://192.168.43.217:5000/invade_info',
					method:"POST",
					data:this.queryInfo,
					success:(res)=>{
						console.log(res.data.information);
						this.messageList=res.data.information;
						this.total = res.data.length
					},
				})
			}
		}
	}
</script>

<style>
	.uni-container{
		background-color: #cad6ca;
	}
	/* #ifndef H5 */
	page {
		padding-top: 85px;
	}
	/* #endif */
	.uni-group {
		display: flex;
		align-items: center;
	}
</style>
