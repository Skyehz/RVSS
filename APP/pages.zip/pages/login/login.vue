<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<text class="title">{{title}}</text>
		</view>
		<view class="uni-page-body"></view>
		<form @submit="formSubmit" @reset="formReset">
			<view class="uni-form-item3 uni-column">
			    <radio-group v-model="logForm.type" name="radio" @change="goWhichHeadpage">
			        <label><radio  value="admin" style="transform:scale(0.6)"  @change="goWhichHeadpage" /><text>管理员</text>
						   <radio value="user" style="transform:scale(0.6)"  @change="goWhichHeadpage"/><text>用户</text>
			        </label>
			    </radio-group>
			</view>
			<view class="uni-form-item uni-column">
				<view class="title"></view>
				<input v-model="logForm.email" class="uni-input" @input="inputData1" name="input" placeholder="输入邮箱" />
			</view >
			<view class="uni-form-item2 uni-column">
				<view class="title"></view>
				<input type = "password" v-model="logForm.password"class="uni-input" @input="inputData2" name="input" placeholder="输入密码" />
			</view>
			
			<view class="uni-padding-wrap uni-common-mt">
				<button @click="goHeadpage_user('success')">登录</button>
			</view>
			<view>
				<!-- 提示信息弹窗 -->
				<uni-popup ref="message" type="message"><uni-popup-message :type="msgType" :message="messageText" :duration="2000"></uni-popup-message></uni-popup>
			</view>
			
			<view class="uni-padding-wrap2 uni-common-mt">
				<navigator url="/pages/register/register">
					<button>注册</button>
				</navigator>
			</view>
		</form>				
	</view>
</template>

<script>
	export default {
		data() {
			return {
				msgType: 'success',
				messageText: '这是一条成功提示',
				value: '',
				logForm:{
					email:"",
					password:"",
					type:""
				},
				title: '欢迎你'
			}
		},
		onReady() {},
		methods: {
			
			goWhichHeadpage:function(evt){
				console.log(evt.detail.value),
				this.logForm.type=evt.detail.value
			},
			inputData1:function(evt){
				this.logForm.email = evt.detail.value
			},
			inputData2:function(evt){
				this.logForm.password = evt.detail.value
			},
			change(e){
				console.log('当前模式：'+e.type+',状态：'+e.show);
			},
			toggle(type) {
				this.type = type
				// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
				this.$refs.popup.open(type)
			},
			goHeadpage_user(type){
				
				if(this.logForm.email!=""&&this.logForm.password!=""){
					
					// uni.redirectTo({
					// 	url:'/pages/headpage/headpage_admin'
					// })
					
					if(this.logForm.type==='user'){
						this.messageText = '成功',
						uni.request({
							url:'http://192.168.43.217:5000/login',
							method:"POST",
							data:this.logForm,
							success:function(res){
								//console.log(this.logForm);
								if(res.data.status==200){
									//console.log(logForm.type);
									uni.redirectTo({
										url:'/pages/headpage/headpage_user'
									})
									//console.log("ghjb")
								}
								else{
									/*登陆失败！！！！！！*/
								}
							}
						})
					};
					if(this.logForm.type==='admin'){
						uni.request({
							url:'http://192.168.43.217:5000/login',
							method:"POST",
							data:this.logForm,
							success:function(res){
								//console.log(this.logForm);
								if(res.data.status==200){
									//console.log(logForm.type);
									//console.log("bxhsjbc");
									uni.redirectTo({
										url:'/pages/headpage/headpage_admin'
									})
								}
								else{
									/*登陆失败！！！！！！*/
								}
							}
						})
					}
				}	
			}
			
		}
	}
</script>

<style lang="scss">
	@import '@/common/uni-nvue.scss';
	// @mixin flex {
	// 	/* #ifndef APP-NVUE */ 
	// 	display: flex;
	// 	/* #endif */
	// 	flex-direction: row;
	// }
	// @mixin height {
	// 	/* #ifndef APP-NVUE */
	// 	height: 100%;
	// 	/* #endif */
	// 	/* #ifdef APP-NVUE */
	// 	flex: 1;
	// 	/* #endif */
	// }
	
	
	.uni-page-body{
		background-color: #cad6ca;
	}
	
	.uni-input{
		border-color: #cad6ca;
	}
	.uni-form-item3{
		margin-top: 100rpx;
	}
	.uni-form-item{
		margin-top: 50rpx;
	}
	.uni-form-item2{
		margin-top: 50rpx;
	}
	.uni-padding-wrap{
		margin-top: 90rpx;
	}
	.uni-padding-wrap2{
		background-color: #CAD6CA;
		margin-top: 40rpx;
	}
	.uni-form-item .title {
	        padding: 20rpx 0;
	}
	.content {
		height: 1400rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #cad6ca;
	}
	
	.logo {
		height: 200rpx;
		width: 200rpx;
		//margin-top: 20rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.title {
		font-size: 36rpx;
		color: #333333;
	}
</style>
