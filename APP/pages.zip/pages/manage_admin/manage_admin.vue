<template>
	<view class="uni-container">
		<uni-table class="table_content" ref="table" :loading="loading" border emptyText="暂无更多数据" >
			<uni-tr>
				<uni-th width="50" align="center">用户名</uni-th>
				<uni-th width="50" align="center">注册邮箱</uni-th>
				<uni-th width="50"align="center">密码</uni-th>
				<!-- <uni-th width="200" align="center">管理用户</uni-th> -->
			</uni-tr>
			<uni-tr v-for="(item, index) in userList" :key="index">
				<uni-td>{{ item[0] }}</uni-td>
				<uni-td>
					<view class="name">{{ item[1] }}</view>
				</uni-td>
				<uni-td align="center">{{ item[2] }}</uni-td>
				<!-- <uni-td>
					<view class="uni-group">
						<button @click="deleteUser" class="uni-button" size="mini" type="warn">删除</button>
					</view>
				</uni-td> -->
			</uni-tr>
		</uni-table>
	</view>
</template>

<script>
	export default {
		created(){
			this.getUserList();
			//console.log(this.userList)
		},
		data() {
			return {
				remarkForm:{
					username:'',
					email:'',
					password:''
				},
				queryInfo:{
					qurey:'',
					pagenum:1,
					pagesize:10
				},
				total: 0,
				loading:false,
				userList:[]
			}
		},
		methods: {
			getUserList(){
				uni.request({
					url:'http://192.168.43.217:5000/users_info',
					method:"POST",
					data:this.queryInfo,
					success:(res)=>{
						console.log(res);
						//console.log(res.data.information);
						this.userList=res.data.information;
						this.total = res.data.length
					},
				})
			},
			deleteUser(){
				uni.removeStorage({
					data:this.queryInfo,
					success() {
						console.log(删除成功)
					}
				})
			}
		}
	}
</script>

<style>
	.table_content{
		background-color: #cad6ca;
	}
	.uni-container{
		background-color: #cad6ca;
	}
	/* #ifndef H5 */
	page {
		padding-top: 85px;
	}
	/* #endif */
	.uni-group {
		display: flex;
		align-items: center;
	}
</style>
