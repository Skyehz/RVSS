<template>
	<view>
		<view class="content">
			<view class="example-body">
				<uni-card :isShadow="true">
					<view>
						<view class="image-box">
							<image class="image" mode="aspectFill" src="http://192.168.43.217:5000/video_feed" />
						</view>
					</view>
				</uni-card>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				
			}
			
		}
	}
</script>

<style>
	.content{
		background-color: #cad6ca;
	}
</style>
