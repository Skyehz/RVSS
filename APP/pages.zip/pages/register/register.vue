<template>
	<view class="content">
		
		<form @submit="formSubmit" @reset="formReset">
			<view class="uni-form-item3 uni-column">
			    <radio-group v-model="regForm.type"  name="radio" @change="goWhichHeadpage">
			        <label><radio value="admin" style="transform:scale(0.4)"  @change="goWhichHeadpage" /><text>管理员</text>
						   <radio value="user" style="transform:scale(0.4)"  @change="goWhichHeadpage"/><text>用户</text>
			        </label>
			    </radio-group>
			</view>
			<view class="uni-form-item uni-column">
				<view class="title"></view>
				<input v-model="regForm.username" class="uni-input" @input="inputData1" name="input" placeholder="输入用户名" />
			</view>
			<view class="uni-form-item2 uni-column">
				<view class="title"></view>
				<input type="password" v-model="regForm.password" class="uni-input" @input="inputData2" name="input" placeholder="输入密码" />
			</view>
			<view class="uni-form-item2 uni-column">
				<input v-model="regForm.email" class="uni-input" @input="inputData3" name="input" placeholder="输入验证邮箱" />
			</view>
			<view class="uni-form-item2 uni-column">
				<button size="mini" @click="sendKey">发送验证码</button>
			</view>
			<view class="uni-form-item2 uni-column">
				<input v-model="regForm.key" class="uni-input" @input="inputData4" name="input" placeholder="在此输入验证码" />
				
			</view>
			
			<view class="uni-padding-wrap uni-common-mt">
				<button@click="isRegister">注册</button>
			</view>
			
			
			<!-- <view class="example-body box">
				<button class="button popup-error" @click="messageToggle('error')"><text class="button-text error-text">失败</text></button>	
			</view> -->
			
			<view>
				<!-- 提示信息弹窗 -->
				<uni-popup ref="message" type="message"><uni-popup-message :type="msgType" :message="messageText" :duration="2000"></uni-popup-message></uni-popup>
			</view>
		</form>	
	</view>
</template>


<script>
	export default {
		data() {
			return {
				type: '',
				msgType: '',
				messageText: '这是一条成功提示',
				regForm:{
					type:'',
					username:'',
					password:'',
					email:'',
					key:'',
					imgcode:[]
				},
				title: '欢迎你'
				
			}
		},
		onReady() {},
		methods: {
			
			change(e){
				console.log('当前模式：'+e.type+',状态：'+e.show);
			},
			toggle(type) {
				this.type = type
				// open 方法传入参数 等同在 uni-popup 组件上绑定 type属性
				this.$refs.popup.open(type)
			},
			goWhichHeadpage:function(evt){
				this.regForm.type = evt.detail.value
			},
			
			inputData1:function(evt){
				this.regForm.username = evt.detail.value
			},
			inputData2:function(evt){
				this.regForm.password = evt.detail.value
			},
			inputData3:function(evt){
				this.regForm.email = evt.detail.value
			},
			inputData4:function(evt){
				this.regForm.key = evt.detail.value
			},
			sendKey:function(evt){
				if(this.regForm.email){
					uni.request({
						url:'http://192.168.43.217:5000/reg_verify',
						method:"POST",
						data:this.regForm,
						success:function(res){
							/*不传*/
						}
					})	
				}
			},
			isRegister:function(type){
				uni.request({
					url:'http://192.168.43.217:5000/register',
					method:"POST",
					data:this.regForm,
					success:function(res){
						console.log(res);
						if(res.data.status==200){
							// if(this.userName!=""&&this.password!=""&&this.email!=""&&this.code!="")
							// {
								// this.msgType = type,
								// this.messageText = '注册成功',
								// this.$refs.message.open(),
								uni.redirectTo({
									url:'/pages/login/login'
								})
							//}
							// if(this.userName==""||this.password==""||his.email==""||this.code=="")
							// {
							// 	this.msgType = type,
							// 	this.messageText = '失败,请检查输入',
							// 	this.$refs.message.open()
							// }
						}
						else{
							/*注册失败！！！！！*/
						}
					}
				})	
				
			}
			
			
		}
	}
</script>

<style>
	.uni-form-item3{
		margin-top: 0rpx;
	}
	.uni-form-item{
		margin-top: 50rpx;
	}
	.uni-form-item2{
		margin-top: 50rpx;
	}
	.uni-padding-wrap{
		margin-top: 50rpx;
	}
	.uni-padding-wrap2{
		background-color: #ffffff;
		margin-top: 50rpx;
	}
	.uni-form-item .title {
	        padding: 20rpx 0;
	}
	.content {
		height: 1400rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #cad6ca;
	}
	
	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 100rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}
	
	.text-area {
		display: flex;
		justify-content: center;
	}
	
	.title {
		font-size: 36rpx;
		color: #333333;
	}
	
	@import '@/common/uni-nvue.scss';
	@mixin flex {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
	}
	@mixin height {
		/* #ifndef APP-NVUE */
		height: 100%;
		/* #endif */
		/* #ifdef APP-NVUE */
		flex: 1;
		/* #endif */
	}
	.box {
		@include flex;
	}
	.button {
		@include flex;
		align-items: center;
		justify-content: center;
		flex: 1;
		height: 35px;
		margin: 0 5px;
		border-radius: 5px;
	}
	
	.button-text {
		color: #fff;
		font-size: 18px;
	}
	.popup-content {
		@include flex;
		align-items: center;
		justify-content: center;
		padding: 15px;
		height: 50px;
		background-color: #fff;
	}
	/* .popup-height {
		@include height;
		width: 200px;
	} */
	.text {
		font-size: 12px;
		color: #333;
	}
	.popup-success {
		color: #fff;
		background-color: #e1f3d8;
	}
	.popup-success2{
		color:#fff;
		background-color: #ffffff;
	}
	
	
	.popup-info {
		color: #fff;
		background-color: #f2f6fc;
	}
	.success-text {
		color: #000000;
	}
	
	.share {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: column;
	}
	
</style>
